<!-- Status: record -->

# Supporting docs — staged origin

origin:
  kind: staged
  id: openxFactory:staging:client-infrastructure-liaison
  path: ideation/staging/client-infrastructure-liaison
  moved: 2026-07-16 (proposal gate, per the staging topic's exit path)

The six fragments in this folder are the staged source material for
`add-client-infrastructure-liaison`, moved verbatim from the staging topic at
the proposal gate. `client-infrastructure-liaison.md` is primary; the
proposal/design/specs derive from these and from the precedents cited in
design.md. Where a fragment and the ratified design disagree (the
`execution_binding` field-shape divergence), design.md D1 records the
reconciliation — the fragments are retained unedited as provenance.

Lifecycle note (2026-07-17): the six fragments' headers were flipped
`Status: staged` → `Status: draft` + `Proposed by:` per the document-lifecycle
transition rule (the manual `git mv` at the proposal gate skipped the header
adjustment the transition tooling normally applies); content is otherwise
unedited. `manifest.yaml` records per-file hashes and the committed source
revision (`4745daa6`).
